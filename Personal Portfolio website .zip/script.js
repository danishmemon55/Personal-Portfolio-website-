var newtyped = new Typed(".loop", { 
    strings: ["Frontend Developer", "Graphic Designer"],
    typeSpeed: 150,
    backSpeed: 150,
    loop: true // Corrected 'looped' to 'loop'
});